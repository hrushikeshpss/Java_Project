package com.keane.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import org.junit.BeforeClass;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.LoginDAO;
import com.keane.training.domain.User;

public class LoginTest {

	static Connection con=null;
	static String url="jdbc:mysql://localhost:3306/userdb";
	@BeforeClass
	public static void init()
	{
	 try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(url,"root","Nttdata123");
		System.out.println(con);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}
	@org.junit.Test
	public void Test()
	{
		LoginDAO dao=new LoginDAO();
		try {
			List<User> lis=dao.validateUser(12);
			for (User user : lis) {
				System.out.println(lis);
			}
		} catch (DAOAppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			}
}
