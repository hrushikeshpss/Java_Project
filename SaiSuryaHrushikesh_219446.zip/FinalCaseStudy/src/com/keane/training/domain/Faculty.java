package com.keane.training.domain;

public class Faculty {
	
	@Override
	public String toString() {
		return "Faculty [fname=" + fname + ", subject=" + subject + ", iname=" + iname + ", id=" + id + "]";
	}
	private String fname;
	private String subject;
	private String iname;
	private String id;
	public Faculty(String fname, String subject, String iname, String id) {
		super();
		this.fname = fname;
		this.subject = subject;
		this.iname = iname;
		this.id = id;
	}
	public Faculty() {
		
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	

}
