package com.keane.training.domain;

public class Student {
	
	@Override
	public String toString() {
		return "Student [sname=" + sname + ", qualification=" + qualification + ", password=" + password + ", id=" + id
				+ ", contactnumber=" + contactnumber + ", address=" + address + ", iname=" + iname + "]";
	}
	private String sname;
	private String qualification;
	private String password;
	private String id;
	private int contactnumber;
	private String address;
	private String iname;
	public Student(String sname, String qualification, String password, String id, int contactnumber, String address,
			String iname) {
		super();
		this.sname = sname;
		this.qualification = qualification;
		this.password = password;
		this.id = id;
		this.contactnumber = contactnumber;
		this.address = address;
		this.iname = iname;
	}

	public Student() {
		
	}

	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(int contactnumber) {
		this.contactnumber = contactnumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	
	

}
