package com.keane.training.domain;

public class Institute {
	
	@Override
	public String toString() {
		return "Institute [iname=" + iname + ", password=" + password + ", affliciationdate=" + affliciationdate
				+ ", id=" + id + ", address=" + address + ", noofseats=" + noofseats + ", noofcourses=" + noofcourses
				+ ", status=" + status + "]";
	}


	
	private String iname;
	private String password;
	private String affliciationdate;
	public Institute() {
		super();
	}



	private String id;
	private String address;
	private int noofseats;
	private int noofcourses;
	private boolean status;
	
	
	
	public Institute(String iname, String password, String affliciationdate, String id, String address, int noofseats,
			int noofcourses, boolean status) {
		super();
		this.iname = iname;
		this.password = password;
		this.affliciationdate = affliciationdate;
		this.id = id;
		this.address = address;
		this.noofseats = noofseats;
		this.noofcourses = noofcourses;
		this.status = status;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAffliciationdate() {
		return affliciationdate;
	}
	public void setAffliciationdate(String affliciationdate) {
		this.affliciationdate = affliciationdate;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getNoofseats() {
		return noofseats;
	}
	public void setNoofseats(int noofseats) {
		this.noofseats = noofseats;
	}
	public int getNoofcourses() {
		return noofcourses;
	}
	public void setNoofcourses(int noofcourses) {
		this.noofcourses = noofcourses;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	

}
