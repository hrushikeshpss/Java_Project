package com.keane.training.domain;

public class Feedback {
	
	@Override
	public String toString() {
		return "Feedback [id=" + id + ", feedback=" + feedback + ", iname=" + iname + "]";
	}
	private String id;
	private String feedback;
	private String iname;
	public Feedback(String id, String feedback, String iname) {
		super();
		this.id = id;
		this.feedback = feedback;
		this.iname = iname;
	}
	public Feedback() {}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	
	

}
