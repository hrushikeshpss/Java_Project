package com.keane.training.domain;

public class Complaint {

	
	String id;
	String complaint;
	String iname;
	@Override
	public String toString() {
		return "Complaints [id=" + id + ", complaint=" + complaint + ", complaint registered on iname=" + iname + "]";
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getComplaint() {
		return complaint;
	}
	public void setComplaint(String complaint) {
		this.complaint = complaint;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public Complaint(String id, String complaint, String iname) {
		super();
		this.id = id;
		this.complaint = complaint;
		this.iname = iname;
	}
	public Complaint() {
		
	}
	
	
}
