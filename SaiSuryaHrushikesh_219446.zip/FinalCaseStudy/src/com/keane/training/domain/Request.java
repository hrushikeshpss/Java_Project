package com.keane.training.domain;

public class Request {
	
	@Override
	public String toString() {
		return "Request [id=" + id + ", request=" + request + ", response=" + response + ", iname=" + iname + "]";
	}
	private String id;
	private String request;
	private String response;
	private String iname;
	public Request(String id, String request, String response, String iname) {
		super();
		this.id = id;
		this.request = request;
		this.response = response;
		this.iname = iname;
	}
	public Request() {
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}

}
