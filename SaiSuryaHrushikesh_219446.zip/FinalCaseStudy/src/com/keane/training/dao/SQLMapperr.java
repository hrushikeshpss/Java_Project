package com.keane.training.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.keane.dbfw.*;
import com.keane.training.*;
import com.keane.training.domain.*;
//import com.keane.domain.Faculty;
//import com.keane.domain.Feedback;
//import com.keane.domain.Institute;
//import com.keane.domain.Request;
//import com.keane.domain.Student;
//import com.keane.domain.Userr;

public class SQLMapperr {
		public static final String FETCHSTUDENT=
			"select * from student";
		public static final String FETCHBYID=
			"select * from student where id=?";
		public static final String FETCHBYINAME=
				"select * from student where iname=?";
		public static final String INSERTSTUDENT=
			"insert into student values(?,?,?,?,?,?,?)";
		public static final String DELETESTUDENT=
			"delete from student where id=?";
		public static final String STUDENTUPDATE=
				"update student set contactnumber=?,address=? where id=? ";
		public static final String UPDATEINAME=
				"update student set iname=? where id=? ";
		
		//institute commands
		public static final String FETCHINSTITUTE=
				"select * from institute";
		public static final String FETCHBYINSTITUTEID=
				"select * from institute where id=?";
		public static final String VALIDATEBYINSTITUTEID=
				"select * from institute where id=? and (iname=? and password=?);";
		public static final String INSERTINSTITUTE=
				"insert into institute values(?,?,?,?,?,?,?,?)";
		public static final String DELETEINSTITUTE=
				"delete from institute where id=?";
		public static final String INSTITUTEUPDATE=
				"update institute set noofseats=?,noofcourses=? where id=? ";
		public static final String INSTITUTESTATUSUPDATE=
				"update institute set status=? where id=? ";
		
		//faculty related
		public static final String INSERTFACULTY=
				"insert into faculty values(?,?,?,?)";
		public static final String FETCHFACULTYBYIID=
				"select * from faculty where id=?";
		
		//user
		public static final String INSERTUSER=
				"insert into user values(?,?,?)";
		//complaintReg
		public static final String COMPLAINTREG=
				"insert into complaint values(?,?,?)";
		public static final String COMPLAINTS=
				"select * from complaint";
		//user commands
		public static final String FETCHUSER=
				"select * from user where id=? and password=?";
		//requests commands
		public static final String INSERTREQUEST=
				"insert into request values(?,?,?,?)";
		public static final String FETCHREQUESTS=
				"select * from request where id=?";
		public static final String FETCHREQUESTBYINAME=
				"select * from request where iname=?";
		public static final String REQUESTUPDATE=
				"update request set response=? where id=? and iname=? ";
		//feedback commands
		public static final String INSERTFEEDBACK=
				"insert into feedback values(?,?,?)";
		public static final String GETFEEDBACKBYINAME=
				"select * from feedback where iname=?";
		
		
		public static final ResultMapper STUDENTMAPPER=
			new ResultMapper()
		{
			public Object mapRow(ResultSet rs) throws SQLException {
			String sname=rs.getString(1);
			String quali=rs.getString(2);
			String pass=null;
			String id=	rs.getString(4);
			int num=rs.getInt(5);
			String add=	rs.getString(6);
			String iname=	rs.getString(7);
			Student s=new Student(sname,quali,pass,id,num,add,iname);
			
				return s;
			}//mapRow
			
		};//Anonymous class
		public static final ResultMapper INSTITUTEMAPPER=
				new ResultMapper()
			{
				public Object mapRow(ResultSet rs) throws SQLException {
				String iname=rs.getString(1);
				String password=null;
				String affliciationdate=rs.getString(3);
				String id=	rs.getString(4);
				String add=	rs.getString(5);
				int noofseats=rs.getInt(6);
				int noofcourses=rs.getInt(7);
				boolean status=rs.getBoolean(8);
				Institute i=new Institute(iname,password,affliciationdate,id,add,noofseats,noofcourses,status);
				
					return i;
				}//mapRow
				
			};//Anonymous class
		

			public static final ResultMapper FACULTYMAPPER=
					new ResultMapper()
				{
					public Object mapRow(ResultSet rs) throws SQLException {
					String fname=rs.getString(1);
					String subject =rs.getString(2);
					String iname =rs.getString(3);
					String id=	rs.getString(4);
					
					
					Faculty f=new Faculty(fname,subject,iname,id);
					
						return f;
					}//mapRow
					
				};//Anonymous class
			

				public static final ResultMapper COMPLAINTMAPPER=
						new ResultMapper()
					{
						public Object mapRow(ResultSet rs) throws SQLException {
						String complaint=rs.getString(2);
						String id=	rs.getString(1);
						String nai=rs.getString(3);
						
						Complaint f=new Complaint(id,complaint,nai);
						
							return f;
						}//mapRow
						
					};//Anonymous class
					
					public static final ResultMapper USERMAPPER=
							new ResultMapper()
						{
							public Object mapRow(ResultSet rs) throws SQLException {
							String role=rs.getString(1);
							String id=	rs.getString(2);
							String password=rs.getString(3);
							
							Userr f=new Userr(role,id,password);
							
								return f;
							}//mapRow
							
						};//Anonymous class	
						public static final ResultMapper REQUESTMAPPER=
								new ResultMapper()
							{
								public Object mapRow(ResultSet rs) throws SQLException {
								
								String id=	rs.getString(1);
								String request=rs.getString(2);
								String response=rs.getString(3);
								String in=	rs.getString(4);
								
								Request f=new Request(id,request,response,in);
								
									return f;
								}//mapRow
								
							};//Anonymous class	
							public static final ResultMapper FEEDBACKMAPPER=
									new ResultMapper()
								{
									public Object mapRow(ResultSet rs) throws SQLException {
									
									String id=	rs.getString(1);
									String feed=rs.getString(2);
									String in=	rs.getString(3);
									
									Feedback f=new Feedback(id,feed,in);
									
										return f;
									}//mapRow
									
								};
//			fname	varchar(10)
//			subject	varchar(10)
//			iname	varchar(10)
//			id	varchar(10)
//		
//		iname	varchar(10)
//		password	varchar(10)
//		affliciationdate	varchar(10)
//		id	varchar(10)
//		address	varchar(10)
//		noofseats	int
//		noofcourses	int
//		status	tinyint(1)
		
//		sname	varchar(10)
//		qualification	varchar(10)
//		password	varchar(10)
//		id	varchar(10)
//		contactnumber	bigint
//		address	varchar(10)
//		iname	varchar(10)

}
