package com.keane.training.dao;
import com.keane.*;
import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.Faculty;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;




public class FacultyDAO {
	//insert faculty
	public static int insertfaculty(final  Faculty f)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper INSERTFACULTY=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					preStmt.setString(1, f.getFname());
					preStmt.setString(2, f.getSubject());
					preStmt.setString(3,f.getIname());
					preStmt.setString(4, f.getId());
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.INSERTFACULTY,INSERTFACULTY);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//insert faculty
	
	//get faculty by institute id
			public static List getfacultybyiid(final String id)
			{
				ConnectionHolder ch=null;
				Connection con=null;
				List c=null;
				
				try {
						ch=ConnectionHolder.getInstance();
						con=ch.getConnection();
					final ParamMapper FACULTYPMAPPERR=new ParamMapper()
					{

						public void mapParam(PreparedStatement preStmt) throws SQLException {
						preStmt.setString(1,id);
											
						}
						
					};//ananymous class
					
				c=DBHelper.executeSelect
				(con,SQLMapperr.FETCHFACULTYBYIID,SQLMapperr.FACULTYMAPPER, FACULTYPMAPPERR );		
			
				} catch (DBConnectionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return c;
				
			}//get faculty by institute id

}
