package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.*;
import com.keane.dbfw.*;

public class ComplaintDAO {
	static Logger log=Logger.getLogger(ComplaintDAO.class);
	
	//complaint registration
	public static int insertcomplaint(final  Complaint f)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper INSERT=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					preStmt.setString(1, f.getId());
					preStmt.setString(2, f.getComplaint());
					preStmt.setString(3, f.getIname());
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.COMPLAINTREG,INSERT);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	
}//Complaint registration
	
	//Feteching all complaints
	public static List getComplaints() throws DBFWException, DAOException, DBConnectionException
	{
		List complaints=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			complaints=DBHelper.executeSelect(con,SQLMapperr.COMPLAINTS,SQLMapperr.COMPLAINTMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return complaints;
		
	}

}
