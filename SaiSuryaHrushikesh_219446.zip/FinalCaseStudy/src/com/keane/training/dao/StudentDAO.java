package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.DBHelperr;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.Student;
import com.keane.training.domain.User;


public class StudentDAO {

static Logger log=Logger.getLogger(StudentDAO.class);
	
	public static List getStudents() throws DBFWException, DAOException, DBConnectionException
	{
		List students=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			students=DBHelperr.executeSelect(con,SQLMapperr.FETCHSTUDENT,SQLMapperr.STUDENTMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return students;
		
	}
	
	//getstudent
	public static List getStudent(final String sid)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		List c=null;
		
		try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
			final ParamMapper STUDENTPMAPPER=new ParamMapper()
			{

				public void mapParam(PreparedStatement preStmt) throws SQLException {
				preStmt.setString(1,sid);
									
				}
				
			};//ananymous class
			
		c=DBHelper.executeSelect
		(con,SQLMapperr.FETCHBYID,SQLMapperr.STUDENTMAPPER, STUDENTPMAPPER );		
	
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return c;
		
	}//getstudent
	
	//insert
	public static int insertStudent(final  Student s)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper INSERTPSTUDENT=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					preStmt.setString(1, s.getSname());
					preStmt.setString(2, s.getQualification());
					preStmt.setString(3, s.getPassword());
					preStmt.setString(4, s.getId());
					preStmt.setInt(5, s.getContactnumber());
					preStmt.setString(6, s.getAddress());
					preStmt.setString(7, s.getIname());
					
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.INSERTSTUDENT,INSERTPSTUDENT);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//insert
	
//Delete
	public static int deletestudent(final  String id)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper DELETEPSTUDENT=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					
					preStmt.setString(1, id);
					
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.INSERTSTUDENT,DELETEPSTUDENT);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;	
	}//delete
	
	//update m.num,address
	public static int updatestudent(final String id,final int mno,final String addres)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper UPDATESTUDENT=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					
					preStmt.setString(3, id);
					preStmt.setInt(1,mno);
					preStmt.setString(2, addres);
					
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.STUDENTUPDATE,UPDATESTUDENT);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;	
	}//update mobilenumber,address
	
	//update institute name
		public static int updateinstitute(final String id,final String inam)
		{
			ConnectionHolder ch=null;
			Connection con=null;
			int result=0;
			
			try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				
				final ParamMapper UPDATESTUDENTINSTITUE=new ParamMapper()
				{

					
					public void mapParam(PreparedStatement preStmt)
							throws SQLException {
						
						preStmt.setString(2, id);
						
						preStmt.setString(1, inam);
						
					}
					
				};
				
			result=DBHelper.executeUpdate(con,SQLMapperr.UPDATEINAME,UPDATESTUDENTINSTITUE);
				
				
			} catch (DBFWException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DBConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return result;	
		}//update institute name
		
		//getstudent
		public static List getStudentbyiname(final String iname)
		{
			ConnectionHolder ch=null;
			Connection con=null;
			List c=null;
			
			try {
					ch=ConnectionHolder.getInstance();
					con=ch.getConnection();
				final ParamMapper STUDENTPMAPPERR=new ParamMapper()
				{

					public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setString(1,iname);
										
					}
					
				};//ananymous class
				
			c=DBHelper.executeSelect
			(con,SQLMapperr.FETCHBYINAME,SQLMapperr.STUDENTMAPPER, STUDENTPMAPPERR );		
		
			} catch (DBConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return c;
			
		}//fetch student by iname
	
}
