package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.Request;

public class RequestDAO {
	//insert request
		public static int insertRequest(final  Request r)
		{
			ConnectionHolder ch=null;
			Connection con=null;
			int result=0;
			
			try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				
				final ParamMapper INSERTPREQUEST=new ParamMapper()
				{

					
					public void mapParam(PreparedStatement preStmt)
							throws SQLException {
						preStmt.setString(1, r.getId());
						preStmt.setString(2, r.getRequest());
						preStmt.setString(3, r.getResponse());
						preStmt.setString(4, r.getIname());
					}
					
				};
				
			result=DBHelper.executeUpdate(con,SQLMapperr.INSERTREQUEST,INSERTPREQUEST);
				
				
			} catch (DBFWException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DBConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return result;
			
			
		}//insert
		
		//feteching requests using id
		
		public static List getrequests(final String id)
		{
			ConnectionHolder ch=null;
			Connection con=null;
			List c=null;
			
			try {
					ch=ConnectionHolder.getInstance();
					con=ch.getConnection();
				final ParamMapper REQUESTPMAPPER=new ParamMapper()
				{

					public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setString(1,id);
										
					}
					
				};//ananymous class
				
			c=DBHelper.executeSelect
			(con,SQLMapperr.FETCHREQUESTS,SQLMapperr.REQUESTMAPPER, REQUESTPMAPPER );		
		
			} catch (DBConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return c;
			
		}
		//feteching requests using iname
		public static List getrequestsbyiname(final String iname)
		{
			ConnectionHolder ch=null;
			Connection con=null;
			List c=null;
			
			try {
					ch=ConnectionHolder.getInstance();
					con=ch.getConnection();
				final ParamMapper REQUESTPMAPPERINAME=new ParamMapper()
				{

					public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setString(1,iname);
										
					}
					
				};//ananymous class
				
			c=DBHelper.executeSelect
			(con,SQLMapperr.FETCHREQUESTBYINAME,SQLMapperr.REQUESTMAPPER, REQUESTPMAPPERINAME );		
		
			} catch (DBConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return c;
			
		}//feteching requests using iname
	
		//update response
		public static int updateresponse(final String sid,final String res,final String iname)
		{
			ConnectionHolder ch=null;
			Connection con=null;
			int result=0;
			try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				
				
				final ParamMapper UPDATETATUS=new ParamMapper()
				{

					
					public void mapParam(PreparedStatement preStmt)
							throws SQLException {
						
						preStmt.setString(1, res);
						preStmt.setString(2, sid);
						preStmt.setString(3, iname);
					}
					
				};
				
			result=DBHelper.executeUpdate(con,SQLMapperr.REQUESTUPDATE,UPDATETATUS);
				
				
			} catch (DBFWException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DBConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			
			return result;	
		}//update response



	
	

}
