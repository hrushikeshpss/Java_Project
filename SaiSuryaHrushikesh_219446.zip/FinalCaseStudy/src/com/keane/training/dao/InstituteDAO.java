package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.Feedback;
import com.keane.training.domain.Institute;


public class InstituteDAO {
static Logger log=Logger.getLogger(StudentDAO.class);
	
	//feteching all institutes
	public static List getinstitutes() throws DBFWException, DAOException, DBConnectionException
	{
		List institutes=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			institutes=DBHelper.executeSelect(con,SQLMapperr.FETCHINSTITUTE,SQLMapperr.INSTITUTEMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return institutes;
		
	}//institutes fetch
	
	//getinstitute
	public static List getinstitute(final String iid)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		List i=null;
		
		try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
			final ParamMapper INSTITUTEPMAPPER=new ParamMapper()
			{

				public void mapParam(PreparedStatement preStmt) throws SQLException {
				preStmt.setString(1,iid);
									
				}
				
			};//ananymous class
			
		i=DBHelper.executeSelect
		(con,SQLMapperr.FETCHBYINSTITUTEID,SQLMapperr.INSTITUTEMAPPER, INSTITUTEPMAPPER );		
	
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}//getinstitute
	
	//insert
	public static int insertinstitute(final  Institute i)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper INSERTINSTITUTE=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					preStmt.setString(1, i.getIname());
					preStmt.setString(2, i.getPassword());
					preStmt.setString(3,i.getAffliciationdate());
					preStmt.setString(4, i.getId());
					preStmt.setString(5, i.getAddress());
					preStmt.setInt(6,i.getNoofseats() );
					preStmt.setInt(7, i.getNoofcourses());
					preStmt.setBoolean(8, false);
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.INSERTINSTITUTE,INSERTINSTITUTE);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//insert
	
//Delete
	public static int deleteinstitute(final  String id)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper DELETEINSTITUTE=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					
					preStmt.setString(1, id);
					
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.DELETEINSTITUTE,DELETEINSTITUTE);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;	
	}//delete
	
	//update num of seats 
	public static int updateinstitute(final int noofs,final String id,final int nooc)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper UPDATEINSTITUTE=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					
					preStmt.setString(3, id);
					preStmt.setInt(1,noofs);
					preStmt.setInt(2,nooc);
					
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.INSTITUTEUPDATE,UPDATEINSTITUTE);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;	
	}//update no of seats,no of courses
	
	//status update by admin
	public static int updateinstitutestatus(final String id,final boolean s)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			
			final ParamMapper UPDATEINSTITUTE=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					
					preStmt.setString(2, id);
					preStmt.setBoolean(1, s);
					
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.INSTITUTESTATUSUPDATE,UPDATEINSTITUTE);
		
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return result;
		
		}//ins status update by admin
	
	//getinstitute by id,iname,pass
		public static List validateinstitute(final String iid,final String iname,final String pass)
		{
			ConnectionHolder ch=null;
			Connection con=null;
			List i=null;
			
			try {
					ch=ConnectionHolder.getInstance();
					con=ch.getConnection();
				final ParamMapper INSTITUTEPMAPPER1=new ParamMapper()
				{

					public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setString(1,iid);
					preStmt.setString(2,iname);
					preStmt.setString(3,pass);
										
					}
					
				};//ananymous class
				
			i=DBHelper.executeSelect
			(con,SQLMapperr.VALIDATEBYINSTITUTEID,SQLMapperr.INSTITUTEMAPPER, INSTITUTEPMAPPER1 );		
		
			} catch (DBConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
			
		}//getinstitute
	}
