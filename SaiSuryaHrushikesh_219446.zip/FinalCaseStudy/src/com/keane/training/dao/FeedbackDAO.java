package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.keane.*;
import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.Feedback;


public class FeedbackDAO {
	
	//insert feedback
			public static int insertFeedback(final  Feedback r)
			{
				ConnectionHolder ch=null;
				Connection con=null;
				int result=0;
				
				try {
					ch=ConnectionHolder.getInstance();
					con=ch.getConnection();
					
					final ParamMapper INSERTFEEDBACK=new ParamMapper()
					{

						
						public void mapParam(PreparedStatement preStmt)
								throws SQLException {
							preStmt.setString(1, r.getId());
							preStmt.setString(2, r.getFeedback());
							preStmt.setString(3, r.getIname());
							
						}
						
					};
					
				result=DBHelper.executeUpdate(con,SQLMapperr.INSERTFEEDBACK,INSERTFEEDBACK);
					
					
				} catch (DBFWException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DBConnectionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return result;
				
				
			}//insert
			
			//get feed back by iname
			public static List getfeedbackbyiname(final String iname)
			{
				ConnectionHolder ch=null;
				Connection con=null;
				List c=null;
				
				try {
						ch=ConnectionHolder.getInstance();
						con=ch.getConnection();
					final ParamMapper FEEDBACKPMAPPERINAME=new ParamMapper()
					{

						public void mapParam(PreparedStatement preStmt) throws SQLException {
						preStmt.setString(1,iname);
											
						}
						
					};//ananymous class
					
				c=DBHelper.executeSelect
				(con,SQLMapperr.GETFEEDBACKBYINAME,SQLMapperr.FEEDBACKMAPPER, FEEDBACKPMAPPERINAME );		
			
				} catch (DBConnectionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return c;
				
			}//feteching feedback by iname
			


}
