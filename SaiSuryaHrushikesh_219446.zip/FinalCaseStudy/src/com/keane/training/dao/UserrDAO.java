package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.*;
import com.keane.training.domain.Userr;

public class UserrDAO {
	//insert user
	public static int insertuser(final  Userr f)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper INSERTUSER=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					preStmt.setString(1, f.getRole());
					preStmt.setString(2, f.getId());
					preStmt.setString(3,f.getPassword());
				
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapperr.INSERTUSER,INSERTUSER);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	return result;
}//insert user
	
	//Fetch user
	public static List getUser(final String id,final String pass)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		List c=null;
		
		try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
			final ParamMapper USERPMAPPER=new ParamMapper()
			{

				public void mapParam(PreparedStatement preStmt) throws SQLException {
				preStmt.setString(1,id);
				preStmt.setString(2,pass);					
				}
				
			};//ananymous class
			
		c=DBHelper.executeSelect
		(con,SQLMapperr.FETCHUSER,SQLMapperr.USERMAPPER, USERPMAPPER );		
	
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return c;
		
	}//getUser
}
