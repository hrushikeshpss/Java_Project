	package com.keane.training.web.handlers;
	import java.io.IOException;
	import java.util.List;

	import javax.servlet.RequestDispatcher;
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;

	import org.apache.log4j.Logger;

	import com.keane.training.dao.DAOAppException;
	import com.keane.training.dao.InstituteDAO;
	import com.keane.training.dao.RegisterDAO;
	import com.keane.training.dao.StudentDAO;
	import com.keane.training.dao.UserrDAO;
	import com.keane.training.domain.Institute;
	import com.keane.training.domain.User;
	import com.keane.training.domain.Userr;

	public class Adminlogin implements com.keane.mvc.HttpRequestHandler {
		static Logger log = Logger.getLogger(Adminlogin.class);

		
		public void handle(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {

			
			
			String id=request.getParameter("AdminId");
			String pwd=request.getParameter("pwd");
			
			boolean isExists;
			
				List list=UserrDAO.getUser(id,pwd);
				int s=list.size();
				if(s==1) {
				isExists = true;
				}
				else {
					isExists = false;
				}
				if (isExists) {
					RequestDispatcher dispatcher = request
							.getRequestDispatcher("Adminhome.jsp");
					HttpSession ses=request.getSession();
					ses.setAttribute("AdminId", id);
					
					dispatcher.forward(request, response);
				} else {
					
					RequestDispatcher dispatcher = request
							.getRequestDispatcher("AdminLogin.jsp");
					request.setAttribute("Err",
							"userid or password is incorrect");
					dispatcher.include(request, response);
						}
				}
			

		}



