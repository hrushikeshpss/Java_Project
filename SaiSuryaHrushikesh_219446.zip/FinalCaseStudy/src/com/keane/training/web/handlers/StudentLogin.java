package com.keane.training.web.handlers;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.InstituteDAO;
import com.keane.training.dao.RegisterDAO;
import com.keane.training.dao.StudentDAO;
import com.keane.training.dao.UserrDAO;
import com.keane.training.domain.Institute;
import com.keane.training.domain.Student;
import com.keane.training.domain.User;
import com.keane.training.domain.Userr;

public class StudentLogin implements com.keane.mvc.HttpRequestHandler {
	static Logger log = Logger.getLogger(StudentLogin.class);

	
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Userr user=new Userr();
		
		String sid=request.getParameter("sid");
		String pwd=request.getParameter("pwd");
		
		
		boolean isExists;
		
			List list=UserrDAO.getUser(sid,pwd);
			int s=list.size();
			if(s==1) {
			isExists = true;
			}
			else {
				isExists = false;
			}
			if (isExists) {
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("Studenthome.jsp");
				HttpSession ses=request.getSession();
				ses.setAttribute("studentid", sid);
				request.setAttribute("sid", sid);
				List s1=StudentDAO.getStudent(sid);
				 
				 Iterator iterator = s1.iterator();  
					while(iterator.hasNext())  
					{
						Student com ;
						com= (Student)iterator.next();
						String n=com.getSname();
						ses.setAttribute("studentname", n);
					}
				dispatcher.forward(request, response);
			} else {
				
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("StudentLogin.jsp");
				request.setAttribute("Err",
						"userid or password is incorrect");
				dispatcher.include(request, response);
					}
			}
		

	}


