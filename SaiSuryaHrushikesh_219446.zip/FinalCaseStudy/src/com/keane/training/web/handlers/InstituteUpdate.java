package com.keane.training.web.handlers;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.FeedbackDAO;
import com.keane.training.dao.InstituteDAO;
import com.keane.training.dao.RegisterDAO;
import com.keane.training.dao.StudentDAO;
import com.keane.training.dao.UserrDAO;
import com.keane.training.domain.Feedback;
import com.keane.training.domain.Institute;
import com.keane.training.domain.User;
import com.keane.training.domain.Userr;

public class InstituteUpdate implements com.keane.mvc.HttpRequestHandler {
	static Logger log = Logger.getLogger(InstituteUpdate.class);

	
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession ses=request.getSession();
		String iid=(String)ses.getAttribute("instituteid");
		
		
		int noofseats=Integer.parseInt(request.getParameter("noofseats"));
		int noofcourses=Integer.parseInt(request.getParameter("noofcourses"));
		
		int i=InstituteDAO.updateinstitute(noofseats, iid, noofcourses);
		if(i!=0) {
			RequestDispatcher req=request.getRequestDispatcher("institutesuccess.jsp");
			req.forward(request, response);
		}
		else
		{

			RequestDispatcher dispatcher = request
					.getRequestDispatcher("institutehome.jsp");
			request.setAttribute("Err",
					"Error occurred try again");
			dispatcher.include(request, response);
		}
		
		
 			
			}
		

	}


