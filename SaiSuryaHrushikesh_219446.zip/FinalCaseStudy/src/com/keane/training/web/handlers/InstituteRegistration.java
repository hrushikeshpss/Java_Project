package com.keane.training.web.handlers;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.InstituteDAO;
import com.keane.training.dao.RegisterDAO;
import com.keane.training.dao.StudentDAO;
import com.keane.training.dao.UserrDAO;
import com.keane.training.domain.Institute;
import com.keane.training.domain.User;
import com.keane.training.domain.Userr;

public class InstituteRegistration implements com.keane.mvc.HttpRequestHandler {
	static Logger log = Logger.getLogger(StudentRegistration.class);

	
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		Institute institute=new Institute();
		Userr user=new Userr();
		
		institute.setIname(request.getParameter("iname"));
		institute.setPassword(request.getParameter("pwd"));
		institute.setAffliciationdate(request.getParameter("affliciationdate"));
		institute.setId(request.getParameter("iid"));
		institute.setAddress(request.getParameter("address"));
		institute.setNoofseats(Integer.parseInt(request.getParameter("noofseats")));
		institute.setNoofcourses(Integer.parseInt(request.getParameter("noofcourses")));
		institute.setStatus(Boolean.parseBoolean(null));
		
		user.setId(request.getParameter("iid"));
		user.setPassword(request.getParameter("pwd"));
		user.setRole("Institute");
		
		String iid=request.getParameter("iid");

		boolean isExists;
		
			List list=InstituteDAO.getinstitute(iid);
			int s=list.size();
			if(s!=0) {
			isExists = true;
			}
			else {
				isExists = false;
			}
			if (isExists) {
				log.info("Institute already registered");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("..\\pages\\InstituteRegistration.jsp");
				request.setAttribute("Err",
						"User already registered with the system");
				dispatcher.forward(request, response);
			} else {
				
				int finalRes = InstituteDAO.insertinstitute(institute);
				
					if(finalRes>0) {
						UserrDAO.insertuser(user);
					RequestDispatcher dispatcher = request.getRequestDispatcher("..\\pages\\sucess.jsp");
					request.setAttribute("success",
							"Institute succesfully registered with the system");
					//request.setAttribute("details", institute);
					dispatcher.forward(request, response);
					}
			}
		

	}

}
