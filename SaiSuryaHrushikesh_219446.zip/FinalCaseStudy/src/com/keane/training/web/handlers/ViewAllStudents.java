package com.keane.training.web.handlers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.ComplaintDAO;
import com.keane.training.dao.DAOException;
import com.keane.training.dao.InstituteDAO;
import com.keane.training.dao.StudentDAO;
import com.keane.training.domain.Institute;

public class ViewAllStudents implements HttpRequestHandler {

	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List studentlist =  StudentDAO.getStudents();
		
			request.setAttribute("slist", studentlist);
			RequestDispatcher rd= request.getRequestDispatcher("ViewStudents.jsp");
			rd.forward(request, response);
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}