package com.keane.training.web.handlers;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.FeedbackDAO;
import com.keane.training.dao.InstituteDAO;
import com.keane.training.dao.RegisterDAO;
import com.keane.training.dao.StudentDAO;
import com.keane.training.dao.UserrDAO;
import com.keane.training.domain.Feedback;
import com.keane.training.domain.Institute;
import com.keane.training.domain.User;
import com.keane.training.domain.Userr;

public class StudentOperations implements com.keane.mvc.HttpRequestHandler {
	static Logger log = Logger.getLogger(StudentOperations.class);

	
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession ses=request.getSession();
		String sid=(String)ses.getAttribute("studentid");
		
		String address=request.getParameter("address");
		int contactnumber=Integer.parseInt(request.getParameter("contactnumber"));
		
		int i=StudentDAO.updatestudent(sid, contactnumber, address);
		if(i!=0) {
			RequestDispatcher req=request.getRequestDispatcher("updatesuccess.jsp");
			req.forward(request, response);
		}
//		Feedback fb=new Feedback();
//		fb.setIname(request.getParameter("iname"));;
//		fb.setFeedback(request.getParameter("feedback"));
//		fb.setId(sid);
//		
//		int j=FeedbackDAO.insertFeedback(fb);
//		if(j!=0) {
//			RequestDispatcher req=request.getRequestDispatcher("updatesuccess.jsp");
//			req.forward(request, response);	
//		}
		
//		boolean isExists;
//		
//			List list=UserrDAO.getUser(sid,pwd);
//			int s=list.size();
//			if(s==1) {
//			isExists = true;
//			}
//			else {
//				isExists = false;
//			}
//			if (isExists) {
//				RequestDispatcher dispatcher = request
//						.getRequestDispatcher("Studenthome.jsp");
//				request.setAttribute("Name", sid);
//				dispatcher.forward(request, response);
//			} else {
//				
//				RequestDispatcher dispatcher = request
//						.getRequestDispatcher("StudentLogin.jsp");
//				request.setAttribute("Err",
//						"userid or password is incorrect");
//				dispatcher.include(request, response);
//					}
			}
		

	}


