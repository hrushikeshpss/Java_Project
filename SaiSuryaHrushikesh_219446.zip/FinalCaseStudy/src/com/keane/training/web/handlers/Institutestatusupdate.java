package com.keane.training.web.handlers;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.FeedbackDAO;
import com.keane.training.dao.InstituteDAO;
import com.keane.training.dao.RegisterDAO;
import com.keane.training.dao.StudentDAO;
import com.keane.training.dao.UserrDAO;
import com.keane.training.domain.Feedback;
import com.keane.training.domain.Institute;
import com.keane.training.domain.User;
import com.keane.training.domain.Userr;

public class Institutestatusupdate implements com.keane.mvc.HttpRequestHandler {
	static Logger log = Logger.getLogger(DeleteInstitute.class);

	
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		
		String iid=request.getParameter("iid");
		
		
		int i=InstituteDAO.updateinstitutestatus(iid,true);
		if(i!=0) {
			RequestDispatcher req=request.getRequestDispatcher("Adminsuccess.jsp");
			req.forward(request, response);
		}
		
		else {
			RequestDispatcher req=request.getRequestDispatcher("error.jsp");
			req.include(request, response);
			
			
		}


			}
		

	}


