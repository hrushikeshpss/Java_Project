package com.keane.training.web.handlers;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.FacultyDAO;
import com.keane.training.dao.InstituteDAO;
import com.keane.training.dao.RegisterDAO;
import com.keane.training.dao.StudentDAO;
import com.keane.training.dao.UserrDAO;
import com.keane.training.domain.Faculty;
import com.keane.training.domain.Institute;
import com.keane.training.domain.User;
import com.keane.training.domain.Userr;

public class FacultyRegister implements com.keane.mvc.HttpRequestHandler {
	static Logger log = Logger.getLogger(FacultyRegister.class);

	
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		Faculty fac=new Faculty();
	
		fac.setId(request.getParameter("fid"));					
		fac.setFname(request.getParameter("fname"));
		fac.setSubject(request.getParameter("subject"));
		HttpSession se=request.getSession();
		String iname1=(String)se.getAttribute("institutename");
		fac.setIname(iname1);
		
		String fid=request.getParameter("fid");

		boolean isExists;
		
			List list=FacultyDAO.getfacultybyiid(fid);
			int s=list.size();
			if(s==1) {
			isExists = true;
			}
			else {
				isExists = false;
			}
			if (isExists) {
				log.info("Faculty already registered");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("Faculty.jsp");
				request.setAttribute("Err",
						"User already registered with the system");
				dispatcher.include(request, response);
			} else {
				
				int finalRes = FacultyDAO.insertfaculty(fac);
				
					if(finalRes>0) {
						
					RequestDispatcher dispatcher = request.getRequestDispatcher("facultyAdditionSuccess.jsp");
					request.setAttribute("success",
							"Faculty succesfully registered with the system");
					//request.setAttribute("details", institute);
					dispatcher.forward(request, response);
					}
			}
		

	}

}
