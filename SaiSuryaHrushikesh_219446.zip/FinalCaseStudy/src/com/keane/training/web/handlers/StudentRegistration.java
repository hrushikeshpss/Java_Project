package com.keane.training.web.handlers;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.RegisterDAO;
import com.keane.training.dao.StudentDAO;
import com.keane.training.dao.UserrDAO;
import com.keane.training.domain.Student;
import com.keane.training.domain.User;
import com.keane.training.domain.Userr;

public class StudentRegistration implements com.keane.mvc.HttpRequestHandler {
	static Logger log = Logger.getLogger(StudentRegistration.class);

	
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		Student student = new Student();
		Userr user =new Userr();
		student.setSname(request.getParameter("sname"));
		student.setQualification(request.getParameter("qualification"));
		student.setPassword(request.getParameter("pwd"));
		student.setId(request.getParameter("sid"));
		student.setContactnumber(Integer.parseInt(request.getParameter("contactnumber")));
		student.setAddress(request.getParameter("address"));
		student.setIname(null);
		
		user.setPassword(request.getParameter("pwd"));
		user.setId(request.getParameter("sid"));
		user.setRole("student");
		
		String sid=request.getParameter("sid");

		boolean isExists;
		
			List list=StudentDAO.getStudent(sid);
			int s=list.size();
			if(s!=0) {
			isExists = true;
			}
			else {
				isExists = false;
			}
			if (isExists) {
				log.info("User already registered");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("..\\pages\\StudentRegistration.jsp");
				request.setAttribute("Err",
						"User already registered with the system");
				dispatcher.forward(request, response);
			} else {
				
				int finalRes = StudentDAO.insertStudent(student);
				
					if(finalRes>0) {
						UserrDAO.insertuser(user);
					RequestDispatcher dispatcher = request.getRequestDispatcher("..\\pages\\sucess.jsp");
					request.setAttribute("success",
							"Student succesfully registered with the system");
//					request.setAttribute("details", user);
					dispatcher.forward(request, response);
					}
			}
		
//		catch (DAOAppException e) {
//			RequestDispatcher dispatcher = request
//					.getRequestDispatcher("error.jsp");
//			request.setAttribute("Err", e.getMessage());
//			dispatcher.forward(request, response);
//		}
	}

}
